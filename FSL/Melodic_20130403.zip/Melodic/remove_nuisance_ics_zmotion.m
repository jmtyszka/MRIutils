function remove_nuisance_ics(feat_dir, options)
% Remove nuisance ICs from 4D BOLD data
% Requires Melodic ICA results
%
% USAGE: remove_nuisance_ics(groups, physio_thresh, tissue_thresh, res, mode)
%
% ARGS:
% feat_dir : .feat directory containing filtered_func_data and .ica dir
% options  : cleanup options structure
% .TR             : sequence repetition time in seconds [2.0]
% .physio_thresh  : fraction of power spectrum above 0.1 Hz for physio ICs [0.5]
% .zmotion_thresh : fraction of power at Nyquist frequency [0.25]
% .mode           : analysis mode (0 = remove ICs, 1 = report ICs only) [1]
%
% Set physio or zmotion threshold to 1.0 to switch off any removal for
% either IC identification method.
%
% AUTHOR : Mike Tyszka
% PLACE  : Caltech
% DATES  : 04/21/2011 JMT Add support for tissue fractions
%          08/10/2011 JMT Generalize for individual feat cleanup
%
% Copyright 2012 California Institute of Technology
% All rights reserved.

% Default arguments
if nargin < 1; feat_dir = pwd; end
if nargin < 2; options = []; end

% Tidy up options structure
if ~isfield(options,'TR'); options.TR = 2.0; end
if ~isfield(options,'physio_thresh'); options.physio_thresh = 0.5; end
if ~isfield(options,'zmotion_thresh'); options.zmotion_thresh = 0.5; end
if ~isfield(options,'mode'); options.mode = 1; end

% Header splash
fprintf('Remove Nuisance ICs\n');
fprintf('-------------------\n');
fprintf('%s\n', datestr(now));
fprintf('TR                  : %0.3f\n', options.TR);
fprintf('Physio threshold    : %0.3f\n', options.physio_thresh);
fprintf('Z-motion threshold  : %0.3f\n', options.zmotion_thresh);
fprintf('Mode                : %d\n', options.mode);

% ICA subdirectory of the feat directory
ica_dir = fullfile(feat_dir,'filtered_func_data.ica');

%% Physiological ICs identified through power spectrum distribution

% Load pspec fraction > 0.1 Hz for all ICs
f_physio = physio_frac(ica_dir, options.TR);
physio_ics = f_physio > options.physio_thresh;

%% Motion ICs associated with sudden motion in the z-direction
zmotion_ics = find_zmotion_ics(ica_dir, options.zmotion_thresh);

% Merge bad ICs from all methods
bad_ics = physio_ics | zmotion_ics;

% Count and report bad ICs from each method
n_ics = length(bad_ics);
n_physio_ics = length(find(physio_ics));
n_zmotion_ics = length(find(zmotion_ics));
n_bad_ics = length(find(bad_ics));

fprintf('Total ICs : %d   Physio ICs : %d   ZMotion ICs : %d   Bad ICs : %d\n',...
  n_ics, n_physio_ics, n_zmotion_ics, n_bad_ics);

% Write nuisance IC list to ICA directory
bad_ic_file = fullfile(ica_dir,'bad_ics.txt');
fd = fopen(bad_ic_file,'w');
if fd < 0
  fprintf('Could not open bad ICs file to write\n');
  return
end

% Use 1-indexing of ICs (Matlab and fsl_regfilt both use 1-indexing)
fprintf(fd, '%d ', find(bad_ics));

% Close bad ICs file
fclose(fd);

% Call script to remove bad ICs
if options.mode == 0
  system(['/Users/jmt/bin/ic_cleanup.sh ' feat_dir]);
end