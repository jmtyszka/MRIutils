function ica_denoise(root_dir)
% Remove nuisance ICs from a filtered_func_data volume
%
% SYNTAX : ica_denois(root_dir)
%
% root_dir = directory containing subject data directories
% mode = processing mode flag (0 = report & cleanup, 1 = report only) [1]
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 08/25/2011 JMT From scratch
%          03/09/2012 JMT Reality checks - modify to scan sessions
%                         automatically

% Root directory
if nargin < 1; root_dir = pwd; end

% BOLD TR in seconds for ASD_rsBOLD study
TR = 2.0;

% IC spectral cutoff frequency (Hz)
hifreq_cutoff = 0.1;

% High frequency fraction for temporal mode - 0.5 is conservative, 0.33 is moderate
hifreq_frac_thresh = 0.33;

% Motion correction critical alpha
moco_alpha = 0.001;

% Create log file in root_dir
log_file = fullfile(root_dir,'clean_physio_ics.log');
fd = fopen(log_file,'w');
if fd < 0
  fprintf('Could not open log file to write - exiting\n');
  return
end

% Header splash
fprintf(fd,'-------------------\n');
fprintf(fd,'ICA Denoising\n');
fprintf(fd,'-------------------\n');
fprintf(fd,'Date             : %s\n', datestr(now));
fprintf(fd,'Root Directory   : %s\n', root_dir);
fprintf(fd,'TR               : %0.1f ms\n', TR * 1000);
fprintf(fd,'High freq cutoff : %0.1f\n', hifreq_cutoff);
fprintf(fd,'High freq thresh : %0.3f\n', hifreq_frac_thresh);
fprintf(fd,'Motion alpha     : %0.3f\n', moco_alpha);
fprintf(fd,'-------------------\n');

% Grab root directory entries
d = dir(root_dir);
sid = {d.name};

% Remove non-subject directories (dirname <> 4 chars)
sid(cellfun('length',sid) ~= 4) = [];

% Init stats structure array
count = 0;

% Column headers
fprintf(fd,'%-12s%2s%6s%6s%6s%12s%12s\n',...
  'SID','#','ICs','Good','Bad','Bad Frac','Bad Var');

% Loop over all subjects
for sc = 1:length(sid);
  
  subj_dir = fullfile(root_dir,sid{sc});
  
  % Locate session .feat directories
  d = dir(fullfile(subj_dir,'*.feat'));
  sess = {d.name};
  n_sess = length(sess);
  
  if n_sess > 0
  
    for fc = 1:n_sess
 
      feat_dir = fullfile(subj_dir, sess{fc});
  
      % Call estimation and nuisance regression function
      stats = remove_nuisance_ics(feat_dir, TR, hifreq_cutoff, hifreq_frac_thresh, moco_alpha);

      if ~isempty(stats)
        
        % Add SID and session info to stats structure
        stats.sid = sid{sc};
        stats.sess = fc;

        % Report results
        fprintf(fd,'%-12s%2d%6d%6d%6d%11.1f%%%11.1f%%\n',...
          stats.sid, stats.sess, stats.n_ics, stats.n_good_ics, stats.n_bad_ics,...
          stats.perc_bad_frac, stats.total_bad_variance);
     
        % Save stats
        count = count + 1;
        all_stats(count) = stats;
        
      end
    
    end
    
  end
  
end

% Report group statistics for cleanup
sids = {all_stats.sid};
ASD_idx = strncmp(sids, 'A', 1);
CTRL_idx = strncmp(sids, 'C', 1);

fprintf(fd,'--------------------\n');

fprintf(fd,'%-12s%2s%6.1f%6.1f%6.1f%11.1f%%%11.1f%%\n',...
  'All ASD','-',...
  mean([all_stats(ASD_idx).n_ics]),...
  mean([all_stats(ASD_idx).n_good_ics]),...
  mean([all_stats(ASD_idx).n_bad_ics]),...
  mean([all_stats(ASD_idx).perc_bad_frac]),...
  mean([all_stats(ASD_idx).total_bad_variance]));
  
fprintf(fd,'%-12s%2s%6.1f%6.1f%6.1f%11.1f%%%11.1f%%\n',...
  'All CTRL','-',...
  mean([all_stats(CTRL_idx).n_ics]),...
  mean([all_stats(CTRL_idx).n_good_ics]),...
  mean([all_stats(CTRL_idx).n_bad_ics]),...
  mean([all_stats(CTRL_idx).perc_bad_frac]),...
  mean([all_stats(CTRL_idx).total_bad_variance]));

