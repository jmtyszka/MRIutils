function ica_deghost(epi_file, TR, corr_thresh, score_thresh, overwrite_ica)
% Remove variable Nyquist ghosts from EPI timeseries
%
% SYNTAX : ica_deghost(epi_file, corr_thresh, overwrite_ica)
%
% ARGS:
% epi_nifti_file = 4D compressed Nifti-1 (.nii.gz) file containing EPI timeseries
% TR             = Repetition time (seconds)     
% corr_thresh    = correlation threshold for Nyquist ICs [0.4]
% score_thresh   = Nyquist score threshold [1]
% overwrite_ica  = overwrite flag for previous ICA results [0]
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 08/25/2011 JMT From scratch
%          03/09/2012 JMT Reality checks - modify to scan sessions
%                         automatically
%          10/04/2012 JMT Spin off into deghosting function
%          01/24/2013 JMT Switch to using spatial correlation with Nyq mask
%
% Copyright 2011-2013 California Institute of Technology.
% All rights reserved.

% Default args
if nargin < 1; help ica_deghost; return; end
if nargin < 2; TR = 2.0; end
if nargin < 3; corr_thresh = 0.4; end
if nargin < 4; score_thresh = 1; end
if nargin < 5; overwrite_ica = 0; end

% Check limits
if corr_thresh >= 1 || corr_thresh <= 0
  fprintf('Nyquist correlation threshold out of bounds [0,1] : %0.3f\n', corr_thresh);
  return
end

% FSL environment
FSL_DIR = getenv('FSL_DIR');
if isempty(FSL_DIR); FSL_DIR = '/usr/local/fsl'; end
melodic_cmd = fullfile(FSL_DIR,'bin','melodic');
regfilt_cmd = fullfile(FSL_DIR,'bin','fsl_regfilt');

%% Run melodic on 4D EPI data

% Parent directory of EPI file
[epi_dir, epi_stub, epi_ext] = fileparts(epi_file);

% Fix .nii.gz extension
if isequal(epi_stub((-3:0)+end),'.nii')
  epi_stub = epi_stub(1:(end-4));
  epi_ext = '.nii.gz';
end

% Fill in containing path if absent
if isempty(epi_dir)
  epi_dir = pwd;
end

% Reconstruct full path to EPI file
epi_file = fullfile(epi_dir, [epi_stub epi_ext]);

% Create log file in same directory as EPI file
log_file = fullfile(epi_dir,'ica_deghost.log');
logfd = fopen(log_file,'w');
if logfd < 0
  fprintf('*** Problem opening %s to write\n', log_file);
  return
end

% Header splash
fprintf('ICA Deghosting\n');
fprintf('-------------------\n');
fprintf('Date             : %s\n', datestr(now));
fprintf('EPI file         : %s\n', epi_file);
fprintf('TR               : %s ms\n', TR);
fprintf('Corr Thresh      : %0.3f\n', corr_thresh);
fprintf('Score Thresh     : %d\n', score_thresh);
fprintf('Overwrite ICA    : %d\n', overwrite_ica);
fprintf('-------------------\n');

% Init log file with header
fprintf(logfd, 'ICA Deghosting\n');
fprintf(logfd, '-------------------\n');
fprintf(logfd, 'Date             : %s\n', datestr(now));
fprintf(logfd, 'EPI file         : %s\n', epi_file);
fprintf(logfd, 'TR               : %s ms\n', TR);
fprintf(logfd, 'Corr Thresh      : %0.3f\n', corr_thresh);
fprintf(logfd, 'Score Thresh     : %d\n', score_thresh);
fprintf(logfd, 'Overwrite ICA    : %d\n', overwrite_ica);
fprintf(logfd, '-------------------\n');

% Key .feat subdirectories
% Assumes ICA was run during FEAT preprocessing, not independently
ica_dir = fullfile(epi_dir,'ICA');

if exist(ica_dir,'dir')

  if overwrite_ica
    fprintf('Overwriting previous ICA results\n');
  else
    fprintf('Using previous ICA results\n');
  end

end

if overwrite_ica
  
  if exist(ica_dir,'dir')
    rmdir(ica_dir,'s');
    mkdir(ica_dir);
  end

  % Construct melodic command
  cmd = sprintf('%s -i %s --nobet --report --tr=%0.3f -o ICA -v >> %s', melodic_cmd, epi_file, TR, log_file);
  fprintf('Running : %s\n', cmd);

  % Run melodic command in shell
  try
    system(cmd);
  catch MELODIC
    fprintf('*** Problem running melodic command - exiting\n');
    fclose(logfd);
    return
  end
  
else
  
  fprintf(logfd, 'ICA already run - continuing\n');
  
end

%% Load IC results

% IC spatial modes
fprintf('Loading spatial modes\n');
ic_smodes = load_ic_smodes(ica_dir);

if isempty(ic_smodes)
  fprintf('*** No IC smodes found - returning\n');
  return
end

% Load explained variance for each IC
all_stats = melodic_stats(ica_dir);

%% Create Nyquist mask

% Load mean image from ICA directory
mean_image = fullfile(ica_dir,'mean.nii.gz');
s = load_nii(mean_image);

% Normalize intensity
s = s/max(s(:));

% Otsu threshold to create head mask
th = graythresh(s(:));
mask = s > th;

% Shift by FOV/2 to create Nyquist mask
ny = size(mask,2);
nyquist_mask = circshift(mask,[0 fix(ny/2) 0]);

%% Search for each class of nuisance ICs

% Identify spatial ICs strongly correlated with Nyquist pattern
is_nyquist = find_nyquist_ics(ic_smodes, nyquist_mask, corr_thresh, score_thresh);

% Bad ICs index list
bad_ics = find(is_nyquist);

% Bad ICs list as a string
bad_ics_list = sprintf('%d ', bad_ics);

%% Write Nyquist IC list to ICA directory

% Open bad ICs file
bad_ic_file = fullfile(ica_dir,'bad_ics.txt');
badfd = fopen(bad_ic_file,'w');
if badfd < 0
  fprintf('Could not open bad ICs file to write\n');
  fclose(logfd);
  return
end

% Write all bad IC indices to single line
fprintf(badfd, '%s', bad_ics_list);

% Close bad ICs file
fclose(badfd);

%% Nuisance IC stats

n_ics = length(is_nyquist);
n_bad_ics = length(bad_ics);

% Total variance explained by bad ICs
total_bad_variance = sum(all_stats.exp_var(is_nyquist));

% Write results summary to log file
fprintf(logfd, 'Number of ICs     : %d\n', n_ics);
fprintf(logfd, 'Number of bad ICs : %d\n', n_bad_ics);
fprintf(logfd, 'Bad IC exp var    : %0.1f%%\n', total_bad_variance);
fprintf(logfd, 'Nuisance ICs:\n');
fprintf(logfd, ' %d', find(is_nyquist));
fprintf(logfd, '\n');
fprintf(logfd, 'Neural ICs:\n');
fprintf(logfd, ' %d', find(~is_nyquist));
fprintf(logfd, '\n');
fprintf(logfd, '---------------------------\n');

%% Regress out nuisance ICs

% Melodic mixing matrix
mix_mat = fullfile(ica_dir, 'melodic_mix');

% Output clean EPI filename
clean_epi_file = fullfile(epi_dir, [epi_stub '_clean' epi_ext]);

% Construct FSL regression filter command
cmd = sprintf('%s -i %s -d %s -o %s -f "%s" -v -a >> %s', ...
  regfilt_cmd, epi_file, mix_mat, clean_epi_file, bad_ics_list, log_file);

% Run regression filter in a shell
fprintf('Running : %s\n', cmd);
try
  system(cmd);
catch REGFILT
  fprintf('*** Problem running regfilt command - exiting\n');
  fclose(logfd);
  return
end

% Close log file
fclose(logfd);
