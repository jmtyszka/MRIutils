function [f_csf, f_wm] = tissue_frac(ica_dir)
% Calculate suprathreshold absolute IC within WM and CSF tissue masks
%
% USAGE: 
% [n_ics, n_physio_ics, pspec_frac] = badics(ica_dir, TR, pspec_thresh)
%
% ARGS:
% ica_dir = Melodic .ica directory containing IC results [pwd]
% TR = Sequence TR in seconds [2.0]
% pspec_thresh = critical fraction for physio assignment [1/3]
% If more than pspec_thresh of the power spectrum is above 0.1Hz,
% the resting-state IC is considered to be physiological in origin.
%
% RETURNS:
% n_ics = total number of ICs
% n_physio_ics = number of physio ICs
% physio_frac = list of power spectrum fractions above 0.1Hz
%
% Copyright 2011 California Institute of Technology.
% All rights reserved.

verbose = 0;

if nargin < 1; ica_dir = pwd; end

if verbose
  fprintf('---------------------------------------\n');
  fprintf('Data directory: %s\n', ica_dir);
  fprintf('Calculating fraction of abs ICs in CSF and WM\n');
end

% Load previously calculated mean timeseries for abs thresh ICs
% CSF and WM within brain mask (ic_tissue_frac script output)

ics_mask_ts = readts(fullfile(ica_dir, 'ics_mask_ts.txt'));
ics_csf_ts  = readts(fullfile(ica_dir, 'ics_csf_ts.txt'));
ics_wm_ts   = readts(fullfile(ica_dir, 'ics_wm_ts.txt'));

% Calculate tissue fractions for CSF and WM
% Ratio of suprathreshold abs IC mask voxels in tissue/brain mask to
% total IC mask voxels in brain mask
f_csf = ics_csf_ts{1} ./ ics_mask_ts{1};
f_wm  = ics_wm_ts{1} ./ ics_mask_ts{1};

function s = readts(fname)

s = [];

fd = fopen(fname,'r');
if fd < 0
  fprintf('Problem opening %s to read\n', fname);
  return
end

s = textscan(fd,'%f');

fclose(fd);

return