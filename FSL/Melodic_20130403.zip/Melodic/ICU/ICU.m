function varargout = ICU(varargin)
% ICU MATLAB code for ICU.fig
%      ICU, by itself, creates a new ICU or raises the existing
%      singleton*.
%
%      H = ICU returns the handle to a new ICU or the handle to
%      the existing singleton*.
%
%      ICU('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ICU.M with the given input arguments.
%
%      ICU('Property','Value',...) creates a new ICU or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ICU_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ICU_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ICU

% Last Modified by GUIDE v2.5 20-Jun-2012 16:07:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ICU_OpeningFcn, ...
                   'gui_OutputFcn',  @ICU_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before ICU is made visible.
function ICU_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ICU (see VARARGIN)

% Choose default command line output for ICU
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Clear the spatial and temporal mode axes
axes(handles.Spatial_Mode);
axis off
set(gca,'color','k');

axes(handles.Temporal_Mode);
axis off
set(gca,'color','w');

% UIWAIT makes ICU wait for user response (see UIRESUME)
% uiwait(handles.MainFigure);


% --- Outputs from this function are returned to the command line.
function varargout = ICU_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Ask user for ICA directory
[fname, dname] = uigetfile({'*.ica'},'Select ICA Directory');

if ~isequal(fname, 0)
  
  % ICA directory
  ica_dir = fullfile(dname,fname);
  
  % Spatial and temporal mode figures are in the report subdirectory
  % Use these for help classify each IC
  report_dir = fullfile(ica_dir,'report');
  
  fprintf('ICU: Determining number of ICs\n');
  try
    ic_stats = textread(fullfile(ica_dir,'melodic_ICstats'));
  catch ICSTATS_ERR
    fprintf('Problem loading IC stats data\n');
    return
  end
  
  % Number of ICs = number of rows of IC stats
  n_ics = size(ic_stats, 1);
  
  % Initialize all ICA related variables
  handles.ic = 1;
  handles.n_ics = n_ics;
  
  % IC Class : 1 = unassigned, 2 = non-neuronal, 3 = neuronal
  handles.ic_class = ones(n_ics,1);
  handles.ic_class_map = [1 1 1; 1 0 0; 0 1 0];
  
  handles.ica_dir = ica_dir;
  handles.report_dir = report_dir;
  
  % Update ICA directory field
  set(handles.ICA_Directory_Field, 'string', ica_dir);
  
  % Store spatial and temporal modes in GUI data
  guidata(hObject, handles);
  
  % Refresh smode and tmode axes and labels
  ICU_Refresh(hObject, handles);
  
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.MainFigure)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete(handles.MainFigure)

%% Additional Functions

function ICU_Refresh(hObject, handles)
% Redraw the figures and update label fields

% Check that a dataset has been loaded
if ~isfield(handles,'ic')
  return
end

% Update current IC fields
set(handles.Current_IC, 'String', sprintf('%d',handles.ic));

switch handles.ic_class(handles.ic)
  case 1
    set(handles.Current_IC_Class, 'String', 'Unassigned');
  case 2
    set(handles.Current_IC_Class, 'String', 'Non-neuronal');
  case 3
    set(handles.Current_IC_Class, 'String', 'Neuronal');
  otherwise
    set(handles.Current_IC_Class, 'String', 'Unknown Class');
end

% Redraw spatial mode mosaic
axes(handles.Spatial_Mode);
smode_file = fullfile(handles.report_dir, sprintf('IC_%d_thresh.png', handles.ic));
smode_mosaic = imread(smode_file,'png');
imshow(smode_mosaic);
axis image off

% Replot temporal mode graph
axes(handles.Temporal_Mode);
tmode_file = fullfile(handles.report_dir, sprintf('t%d.png', handles.ic));
[tmode_plot, tmode_map] = imread(tmode_file,'png');
tmode_plot = ind2rgb(tmode_plot, tmode_map);
tmode_plot = imresize(tmode_plot, 2,'bicubic');
imshow(tmode_plot, tmode_map);
axis image off

% Redraw IC classification plot
axes(handles.IC_Class_Plot);
imshow(handles.ic_class, handles.ic_class_map);
axis image off
hold on
plot(1,handles.ic,'k+','MarkerSize',14);

% --------------------------------------------------------------------
function SaveMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to SaveMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

neuronal_ics_file = fullfile(handles.ica_dir,'neuronal_ics.txt');
fd = fopen(neuronal_ics_file,'w');
if fd < 0
  fprintf('Problem opening %s to write\n', neuronal_ics_file);
  return
end

for ic = 1:handles.n_ics
  if handles.ic_class(ic) == 3
    fprintf(fd,'%d ',ic);
  end
end
fprintf(fd,'\n');

% Close output file
fclose(fd);


% --- Executes on key press with focus on MainFigure and none of its controls.
function MainFigure_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to MainFigure (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)

% Check that a dataset has been loaded
if ~isfield(handles,'ic')
  return
end

% Get key pressed
this_key = lower(eventdata.Key);

switch this_key
  
  case 'z'
    
    % Neural IC
    handles.ic_class(handles.ic) = 3;
    handles.ic = handles.ic + 1;
    
  case 'x'
    
    % Non-neuronal IC
    handles.ic_class(handles.ic) = 2;
    handles.ic = handles.ic + 1;
    
  case 'leftarrow'
    
    handles.ic = handles.ic - 1;
    
  case 'rightarrow'
    
    handles.ic = handles.ic + 1;
    
  otherwise
    
    % Do nothing
    
end

% Wrap IC number
handles.ic = mod(handles.ic-1,handles.n_ics) + 1;

% Resave GUI data
guidata(hObject, handles);

% Refresh figures
ICU_Refresh(hObject, handles);
