function ica_lowpass(epi_file, TR, freq_cutoff, pspec_frac)
% Low pass filter an EPI timeseries by ICA
%
% SYNTAX : ica_lowpass(epi_file, TR, freq_cutoff, pspec_frac)
%
% epi_nifti_file = 4D compressed Nifti-1 (.nii.gz) file containing EPI timeseries
% TR             = volume TR in seconds
% freq_cutoff    = frequency cutoff in Hz for assessing nuisance components [0.1 Hz]
% pspec_frac     = minimum fraction of power > cutoff for a nuisance component [0.33]
%
% AUTHOR : Mike Tyszka, Ph.D.
% PLACE  : Caltech
% DATES  : 08/25/2011 JMT From scratch
%          03/09/2012 JMT Reality checks - modify to scan sessions
%                         automatically
%          10/04/2012 JMT Spin off into deghosting function
%          01/24/2013 JMT Rename as a lowpass ICA
%
% Copyright 2011-2013 California Institute of Technology.
% All rights reserved.

% Default args
if nargin < 1; help ica_deghost; return; end
if nargin < 2; TR = 2.0; end
if nargin < 3; freq_cutoff = 0.1; end
if nargin < 4; pspec_frac = 0.33; end

% FSL environment
FSL_DIR = getenv('FSL_DIR');
if isempty(FSL_DIR); FSL_DIR = '/usr/local/fsl'; end
melodic_cmd = fullfile(FSL_DIR,'bin','melodic');
regfilt_cmd = fullfile(FSL_DIR,'bin','fsl_regfilt');

%% Run melodic on 4D EPI data

% Parent directory of EPI file
[epi_dir, epi_stub, epi_ext] = fileparts(epi_file);

% Fix .nii.gz extension
if isequal(epi_stub((-3:0)+end),'.nii')
  epi_stub = epi_stub(1:(end-4));
  epi_ext = '.nii.gz';
end

% Fill in containing path if absent
if isempty(epi_dir)
  epi_dir = pwd;
end

% Reconstruct full path to EPI file
epi_file = fullfile(epi_dir, [epi_stub epi_ext]);

% Create log file in same directory as EPI file
log_file = fullfile(epi_dir,'ica_deghost.log');
logfd = fopen(log_file,'w');
if logfd < 0
  fprintf('*** Problem opening %s to write\n', log_file);
  return
end

% Init log file with header
fprintf(logfd, 'ICA Deghosting\n');
fprintf(logfd, '-------------------\n');
fprintf(logfd, 'Date             : %s\n', datestr(now));
fprintf(logfd, 'EPI file         : %s\n', epi_file);
fprintf(logfd, 'TR               : %0.1f ms\n', TR * 1000);
fprintf(logfd, 'High freq cutoff : %0.1f\n', freq_cutoff);
fprintf(logfd, 'Power threshold : %0.3f\n', pspec_frac);
fprintf(logfd, '-------------------\n');

% Key .feat subdirectories
% Assumes ICA was run during FEAT preprocessing, not independently
ica_dir = fullfile(epi_dir,'ICA');

if exist(ica_dir,'dir')

  % Ask user for permission to overwrite existing ICA
  resp = input('Overwrite existing ICA results (Y/n)? [n] ','s');
  
  if isempty(resp)
    resp = 'n';
  end
  
  switch resp
    case 'Y'
      overwrite_ica = true;
    otherwise
      overwrite_ica = false;
  end
  
else
  overwrite_ica = true;
end

if overwrite_ica
  
  if exist(ica_dir,'dir')
    rmdir(ica_dir,'s');
    mkdir(ica_dir);
  end

  % Construct melodic command
  cmd = sprintf('%s -i %s --nobet --report --tr=%0.3f -o ICA -v >> %s', melodic_cmd, epi_file, TR, log_file);
  fprintf('Running : %s\n', cmd);

  % Run melodic command in shell
  try
    system(cmd);
  catch MELODIC
    fprintf('*** Problem running melodic command - exiting\n');
    fclose(logfd);
    return
  end
  
else
  
  fprintf(logfd, 'ICA already run - continuing\n');
  
end

%% Load IC results

% IC temporal modes
ic_tmodes = load_ic_tmodes(ica_dir);

if isempty(ic_tmodes)
  fprintf('*** No IC tmodes found - returning\n');
  return
end

% Load explained variance for each IC
all_stats = melodic_stats(ica_dir);

%% Search for each class of nuisance ICs

% Identify nuisance ICs
is_nuisance = find_hifreq_ics(ic_tmodes, TR, freq_cutoff, pspec_frac);
bad_ics = find(is_nuisance);
bad_ics_list = sprintf('%d ', bad_ics);

%% Write nuisance IC list to ICA directory

% Open bad ICs file
bad_ic_file = fullfile(ica_dir,'bad_ics.txt');
badfd = fopen(bad_ic_file,'w');
if badfd < 0
  fprintf('Could not open bad ICs file to write\n');
  fclose(logfd);
  return
end

% Write all bad IC indices to single line
fprintf(badfd, '%s', bad_ics_list);

% Close bad ICs file
fclose(badfd);

%% Nuisance IC stats

n_ics = length(is_nuisance);
n_bad_ics = sum(is_nuisance);

% Total variance explained by bad ICs
total_bad_variance = sum(all_stats.exp_var(is_nuisance));

% Write results summary to log file
fprintf(logfd, 'Number of ICs     : %d\n', n_ics);
fprintf(logfd, 'Number of bad ICs : %d\n', n_bad_ics);
fprintf(logfd, 'Bad IC exp var    : %d\n', total_bad_variance);
fprintf(logfd, 'Nuisance ICs:\n');
fprintf(logfd, ' %d', find(is_nuisance)); fprintf('\n');
fprintf(logfd, 'Neural ICs:\n');
fprintf(logfd, ' %d', find(~is_nuisance)); fprintf('\n');
fprintf(logfd, '---------------------------\n');

%% Regress out nuisance ICs

% Melodic mixing matrix
mix_mat = fullfile(ica_dir, 'melodic_mix');

% Output clean EPI filename
clean_epi_file = fullfile(epi_dir, [epi_stub '_clean' epi_ext]);

% Construct FSL regression filter command
cmd = sprintf('%s -i %s -d %s -o %s -f "%s" -v >> %s', ...
  regfilt_cmd, epi_file, mix_mat, clean_epi_file, bad_ics_list, log_file);

% Run regression filter in a shell
fprintf('Running : %s\n', cmd);
try
  system(cmd);
catch REGFILT
  fprintf('*** Problem running regfilt command - exiting\n');
  fclose(logfd);
  return
end

% Close log file
fclose(logfd);
