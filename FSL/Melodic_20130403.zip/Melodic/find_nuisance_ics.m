function [is_nuisance, stats] = find_nuisance_ics(feat_dir, TR, hifreq_cutoff, hifreq_frac_thresh, moco_alpha)
% Remove nuisance ICs from 4D BOLD data - requires Melodic ICA results
%
% USAGE: [is_nuisance, stats] = find_nuisance_ics(feat_dir, TR, hifreq_cutoff, hifreq_frac_thresh, moco_alpha)
%
% ARGS:
% feat_dir           = .feat directory containing filtered_func_data and .ica dir
% TR                 = sequence repetition time in seconds [2.0]
% hifreq_cutoff      = lower limit of nuisance frequencies (Hz) [0.1]
% hifreq_frac_thresh = critical fraction of spectral power above cutoff for nuisance [0.5]
% moco_alpha         = critical prob for significance of motion correlation [0.05] 
%
% RETURNS:
% is_nuisance  = logical mask for nuisance ICs (true = nuisance)
% stats        = stats structure from analysis
%
% AUTHOR : Mike Tyszka
% PLACE  : Caltech
% DATES  : 04/21/2011 JMT Add support for tissue fractions
%          08/10/2011 JMT Generalize for individual feat cleanup
%          03/19/2012 JMT Add return stats structure
%
% Copyright 2012 California Institute of Technology.
% All rights reserved.

% Plot flags
do_figure = 1;
do_summary = 1;

% Default arguments
if nargin < 1; feat_dir = pwd; end
if nargin < 2; TR = 2.0; end
if nargin < 3; hifreq_cutoff = 0.1; end
if nargin < 4; hifreq_frac_thresh = 0.33; end
if nargin < 5; moco_alpha = 0.001; end

% Init return args
is_nuisance = [];
stats = [];

% Key .feat subdirectories
% Assumes ICA was run during FEAT preprocessing, not independently
ica_dir = fullfile(feat_dir,'filtered_func_data.ica');

%% Load IC and MOCO data

% IC temporal modes
ic_tmodes = load_ic_tmodes(ica_dir);

if isempty(ic_tmodes)
  fprintf('*** No IC tmodes found - returning\n');
  return
end

% MOCO parameters
moco_pars = load_moco_pars(feat_dir);

% Load explained variance for each IC
all_stats = melodic_stats(ica_dir);

%% Search for each class of nuisance ICs

% Identify high frequency ICs
is_hifreq = find_hifreq_ics(ic_tmodes, TR, hifreq_cutoff, hifreq_frac_thresh);

% Identify motion ICs
is_motion = find_motion_ics(ic_tmodes, moco_pars, moco_alpha);

% Combine all nuisance ICs
is_nuisance = is_hifreq | is_motion;

%% Write nuisance IC list to ICA directory

% Open bad ICs file
bad_ic_file = fullfile(ica_dir,'bad_ics.txt');
fd = fopen(bad_ic_file,'w');
if fd < 0
  fprintf('Could not open bad ICs file to write\n');
  return
end

% Write all bad IC indices to single line
fprintf(fd, '%d ', find(is_nuisance));

% Close bad ICs file
fclose(fd);

%% Nuisance IC stats structure

n_ics = length(is_nuisance);
n_bad_ics = sum(is_nuisance);

% Total variance explained by bad ICs
total_bad_variance = sum(all_stats.exp_var(is_nuisance));

% Construct stats return structure
stats.n_ics = n_ics;
stats.n_good_ics = n_ics - n_bad_ics;
stats.n_bad_ics = n_bad_ics;
stats.perc_bad_frac = n_bad_ics / n_ics * 100;
stats.total_bad_variance = total_bad_variance;
stats.ica_dir = ica_dir;

%% Plot figure and summary

if do_figure
  
  figure(22); clf
  
  % Motion ICs, physio ICs, union and differences
  subplot(311), bar(is_nuisance); axis tight; set(gca,'YLim',[0 1.5]); title('High Freq & Motion');
  subplot(312), bar(is_hifreq & ~is_motion); axis tight; set(gca,'YLim',[0 1.5]); title('Only High Freq');
  subplot(313), bar(is_motion & ~is_hifreq); axis tight; set(gca,'YLim',[0 1.5]); title('Only Motion');
  
end

if do_summary
  
  fprintf('\n');
  fprintf('---------------------------\n');
  fprintf('Nuisance IC Summary\n');
  fprintf('---------------------------\n');
  
  % Nuisance parameters
  fprintf('TR               : %0.1f ms\n', TR * 1000);
  fprintf('High freq cutoff : %0.1f\n', hifreq_cutoff);
  fprintf('High freq thresh : %0.3f\n', hifreq_frac_thresh);
  fprintf('Motion alpha     : %0.3f\n', moco_alpha);
  fprintf('---------------------------\n');
  
  % High frequency only ICs
  fprintf('High frequency only:\n');
  fprintf(' %d', find(is_hifreq & ~is_motion)); fprintf('\n');
  
  % Motion only ICs
  fprintf('Motion only:\n');
  fprintf(' %d', find(is_motion & ~is_hifreq)); fprintf('\n');
  
  % Motion and high frequency
  fprintf('Motion and high frequency:\n');
  fprintf(' %d', find(is_motion & is_hifreq)); fprintf('\n')
  
  % Good ICs
  fprintf('Neural ICs:\n');
  fprintf(' %d', find(~is_motion & ~is_hifreq)); fprintf('\n');
  
  fprintf('---------------------------\n');

end


