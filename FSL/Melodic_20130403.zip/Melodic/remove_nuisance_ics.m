function stats = remove_nuisance_ics(feat_dir, TR, hifreq_cutoff, hifreq_frac_thresh, moco_alpha)
% Remove nuisance ICs from 4D BOLD data - requires Melodic ICA results
%
% USAGE: stats = remove_nuisance_ics(feat_dir, TR, hifreq_cutoff, hifreq_frac_thresh, moco_alpha)
%
% ARGS:
% feat_dir           = .feat directory containing filtered_func_data and .ica dir
% TR                 = sequence repetition time in seconds [2.0]
% hifreq_cutoff      = lower limit of nuisance frequencies (Hz) [0.1]
% hifreq_frac_thresh = critical fraction of spectral power above cutoff for nuisance [0.5]
% moco_alpha         = critical prob for significance of motion correlation [0.05] 
%
% RETURNS:
% is_nuisance  = logical mask for nuisance ICs (true = nuisance)
% stats        = stats structure from analysis
%
% AUTHOR : Mike Tyszka
% PLACE  : Caltech
% DATES  : 04/21/2011 JMT Add support for tissue fractions
%          08/10/2011 JMT Generalize for individual feat cleanup
%          03/19/2012 JMT Add return stats structure

% Default arguments
if nargin < 1; feat_dir = pwd; end
if nargin < 2; TR = 2.0; end
if nargin < 3; hifreq_cutoff = 0.1; end
if nargin < 4; hifreq_frac_thresh = 0.33; end
if nargin < 5; moco_alpha = 0.001; end

% Default return args
stats = [];

%% Call find nuisance IC function
[is_nuisance, stats] = find_nuisance_ics(feat_dir, TR, hifreq_cutoff, hifreq_frac_thresh, moco_alpha);

if isempty(is_nuisance)
  fprintf('*** Nothing to do - returning\n');
  return
end

% Indices of bad ICs
bad_ics = find(is_nuisance);

if length(bad_ics) < 1
  fprintf('No nuisance ICs found - returning\n');
  return
end

%% Write nuisance IC list to ICA directory

% Create bad ICs text file in ICA directory
bad_ic_file = fullfile(stats.ica_dir,'bad_ics.txt');
fd = fopen(bad_ic_file,'w');
if fd < 0
  fprintf('Could not open bad ICs file to write\n');
  return
end

% Write all bad IC indices to single line
fprintf(fd, '%d ', bad_ics);

% Close bad ICs file
fclose(fd);

%% Call script to remove bad ICs
try
  system(['/Users/jmt/bin/ic_cleanup.sh ' feat_dir]);
catch IC_CLEAN
  fprintf('*** Problem calling ic_cleanup.sh script\n');
  fprintf('*** Exiting\n');
  rethrow IC_CLEAN
end

